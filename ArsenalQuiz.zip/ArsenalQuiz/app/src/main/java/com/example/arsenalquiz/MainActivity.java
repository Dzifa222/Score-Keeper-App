package com.example.arsenalquiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    public void submitAnswer(View view) {
        result();
    }

    private void result() {
        // Referencing the Views
        EditText resultQuestion1 = (EditText) findViewById(R.id.qtn1EditText);
        RadioButton resultQuestion2Ans1996 = (RadioButton) findViewById(R.id.qtn2RB1);
        RadioButton resultQuestion2Ans1995 = (RadioButton) findViewById(R.id.qtn2RB2);
        RadioButton resultQuestion2Ans1990 = (RadioButton) findViewById(R.id.qtn2RB3);
        CheckBox resultQuestion3AnsEmirates = (CheckBox) findViewById(R.id.qtn1CHB1);
        CheckBox resultQuestion3AnsOldTraford = (CheckBox) findViewById(R.id.qtn1CHB2);
        CheckBox resultQuestion3AnsHighBury = (CheckBox) findViewById(R.id.qtn1CHB3);
        RadioButton resultQuestion4AnsJoseMourinho = (RadioButton) findViewById(R.id.qt4RB1);
        RadioButton resultQuestion4AnsUnaiEmery = (RadioButton) findViewById(R.id.qtn4RB2);
        RadioButton resultQuestion4AnsPepGuardiola = (RadioButton) findViewById(R.id.qt4RB3);
        EditText resultQuestion5 = (EditText) findViewById(R.id.qtn5EditText);

        // Edit  Arsenal first Coach=(EditText)  findViewById (R.id. qtn1EditText);
        int score1 = 0;
        String answerForQuestion1 = "George Graham";
        String userAnswerForQuestion1 = resultQuestion1.getText().toString();
        if (answerForQuestion1.equals(userAnswerForQuestion1)) {
            score1 = score1 + 1;
        }
        else {
            score1 += 0; //The value of score1 remains unchanged since the answer was wrong
        }

        // Edit  Arsenal Owner =(EditText)  findViewById (R.id. qtn5EditText);

        String answerForQuestion5 = "Stan Kroenke";
        String userAnswerForQuestion5 = resultQuestion5.getText().toString();
        if (answerForQuestion5.equals(userAnswerForQuestion5)) {
            score1 = score1 + 1;
        }
        else {
            score1 += 0; //The value of score1 remains unchanged since the answer was wrong
        }

        //   onRadioButtonClicked (View view) {

        boolean answer1996 = resultQuestion2Ans1996.isChecked();
        if  (answer1996 == true) {
            score1 = score1 + 1;
        }
        else {
            score1 += 0; //The value of score1 remains unchanged since the answer was wrong
        }

        //    onRadioButtonClicked  (View view)  {

        boolean answer1995 = resultQuestion2Ans1995.isChecked();
        if (answer1995 == true) {
            score1 = score1 + 0;
        }

        //   onRadioButtonClicked  (View view)  {
        boolean answer1990 = resultQuestion2Ans1990.isChecked();
        if (answer1990 == true) {
            score1 = score1 + 0;
        }

        //  onRadioButtonClicked  (View view)  {
        boolean answerJoseMourihno = resultQuestion4AnsJoseMourinho.isChecked();
        if (answerJoseMourihno == true) {
            score1 = score1 + 0;
        }

        //  onRadioButtonClicked  (View view)  {
        boolean answerUnaiEmery = resultQuestion4AnsUnaiEmery.isChecked();
        if (answerUnaiEmery == true) {
            score1 = score1 + 1;
        }
        else {
            score1 += 0; //The value of score1 remains unchanged since the answer was wrong
        }

        // onRadioButtonClicked  (View view)   {
        boolean answerPepGuardiola = resultQuestion4AnsPepGuardiola.isChecked();
        if (answerPepGuardiola == true) {
            score1 = score1 + 0;
        }

        //  onCheckedBoxClicked  (View view)   {
        boolean answerEmirates = resultQuestion3AnsEmirates.isChecked();

        //  onCheckedBoxClicked   (View view)   {
        boolean answerOldTraford = resultQuestion3AnsOldTraford.isChecked();

        //  onCheckedBoxClicked   (View view)   {
        boolean answerHighBury =resultQuestion3AnsHighBury .isChecked ();
        if (answerOldTraford == false && answerEmirates == true && answerHighBury == true) {
             score1 =score1 +1;
        }
        else {
            score1 += 0; //The value of score1 remains unchanged since the answer was wrong
        }

        Toast.makeText(this, "Number of correct answers: " + score1, Toast.LENGTH_LONG).show();
    }
}




